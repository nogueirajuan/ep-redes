#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <stdio.h>
#include <unistd.h>
#define __USE_GNU
#include <pthread.h>

#define MAX 80 //tamanho da mensagem
#define PORT 5000 //porta onde sera realizada a conexao com os clientes
#define NUMERO_THREADS 5 //quantidade de threads
#define SA struct sockaddr 

pthread_mutex_t request_mutex = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
pthread_cond_t got_request = PTHREAD_COND_INITIALIZER;

int numero_requisicoes = 0;

/////////////////////////////////////////////////////////////////////////////////////////
//Configuracao das threads e processamento das requisicoes
/////////////////////////////////////////////////////////////////////////////////////////
struct mensagem_cliente
{
    char *texto;
    struct mensagem_cliente *prox;
};

struct mensagem_cliente *mensagens = NULL;
struct mensagem_cliente *ultima_mensagem = NULL;

/**
 * Metodo que insere uma mensagem na lista ligada de gerenciamento da thread mestre
*/
void adicionar_requisicao(char *texto, pthread_mutex_t *p_mutex, pthread_cond_t *p_cond_var)
{
    int rc;
    struct mensagem_cliente *a_request;

    a_request = (struct mensagem_cliente *)malloc(sizeof(struct mensagem_cliente));
    if (!a_request)
    {
        fprintf(stderr, "Nova requisicao: estouro de memoria\n");
        exit(1);
    }

    a_request->texto = texto;
    a_request->prox = NULL;

    rc = pthread_mutex_lock(p_mutex);

    if (numero_requisicoes == 0)
    {
        mensagens = a_request;
        ultima_mensagem = a_request;
    }
    else
    {
        ultima_mensagem->prox = a_request;
        ultima_mensagem = a_request;
    }

    numero_requisicoes++;

    rc = pthread_mutex_unlock(p_mutex);

    rc = pthread_cond_signal(p_cond_var);
}

/**
 * Metodo que remove cabeca da lista ligada para que seja processado
*/
struct mensagem_cliente *consomeRequisicao(pthread_mutex_t *p_mutex)
{
    int rc;
    rc = pthread_mutex_lock(p_mutex);

    struct mensagem_cliente *a_request;
    if (numero_requisicoes > 0)
    {
        a_request = mensagens; 
        mensagens = a_request->prox;
        if (mensagens == NULL)
        {
            ultima_mensagem = NULL;
        }

        numero_requisicoes--;
    }
    else
    {
        a_request = NULL;
    }

    rc = pthread_mutex_unlock(p_mutex);

    return a_request;
}

/**
 * funcao responsavel por processar de fato a requisicao. No nosso caso estamos logando qual a thread capturou a 
 * requisicao no inicio do processamento e a conclusao da operacao
*/
void processa_requisicao(struct mensagem_cliente *a_request, int thread_id)
{
    if (a_request)
    {
        printf("=====> Thread ID: '%d'\t - Iniciou\n", thread_id);
        sleep(5);
        printf("=====> Thread ID: '%d'\t - processamento concluido para a mensagem: '%s'\n", thread_id, a_request->texto);
        fflush(stdout);
    }
}

/**
 * funcao executada por toda thread. Ela verifica se existem mensagens a serem processadas na lista ligada,
 * caso exista, a processa
 * caso contrario a thread entra em modo de espera ate que volte a executar esta funcao novamente em busca de 
 * requisicoes pendentes de processamento
 */
void *processamento_thread(void *valor)
{
    int rc;
    struct mensagem_cliente *a_request;
    int thread_id = *((int *)valor);

    while (1)
    {
        if (numero_requisicoes > 0)
        {
            a_request = consomeRequisicao(&request_mutex);
            if (a_request)
            {
                processa_requisicao(a_request, thread_id);
                free(a_request);
            }
        }
        else
        {
            rc = pthread_cond_wait(&got_request, &request_mutex);
        }
    }
}


/////////////////////////////////////////////////////////////////////////////////////////
//Configuracao do socket
/////////////////////////////////////////////////////////////////////////////////////////

// Function designed for chat between client and server. 
void func(int sockfd) 
{ 
	char buff[MAX];    
    bzero(buff, MAX); 

    read(sockfd, buff, sizeof(buff));

    //char mensagem[MAX];
    char *mensagem = malloc(sizeof(char) * MAX);
    
    strcpy(mensagem, buff);

    adicionar_requisicao(mensagem, &request_mutex, &got_request);
    printf("Requisicao do cliente: '%s' adicionada a estrutura de dados\n", buff); 

    bzero(buff, MAX); 
}

int main() 
{ 
    int i;
    int thr_id[NUMERO_THREADS];
    pthread_t p_threads[NUMERO_THREADS];

    printf("Inicializando threads..\n\n");

    //inicializando threads
    for (i = 0; i < NUMERO_THREADS; i++)
    {
        thr_id[i] = i;
        pthread_create(&p_threads[i], NULL, processamento_thread, (void *)&thr_id[i]);
    }

    sleep(3);
    printf("Threads disponiveis..\n");


	int sockfd, connfd, len; 
	struct sockaddr_in servaddr, cli; 

	//Cria socket
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("Falha ao criar socket...\n"); 
		exit(0); 
	} 
	else
		printf("Socket criado com sucesso..\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	//associando socket a porta parametrizada
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(PORT); 

	//checa associacao de porta ao socket
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("Falha ao associar porta...\n"); 
		exit(0); 
	} 
	else
		printf("Conexao com porta realizada..\n"); 

	//Servidor checa a conexao de clientes e a chegada de mensagens
	if ((listen(sockfd, 5)) != 0) { 
		printf("Falha ao subir servidor...\n"); 
		exit(0); 
	} 
	else
		printf("Servidor ativo!\n"); 
	len = sizeof(cli); 

	//consome requisicao do cliente e as armzena em estrutura de dados para distribuicao entre as threads escravas
    char buff[MAX]; 
    for (;;) { 
        connfd = accept(sockfd, (SA*)&cli, &len); 
        if (connfd < 0) { 
            printf("Falha ao receber requisicao, o programa sera encerrado...\n"); 
            exit(0); 
        } 
        else
            printf("Requisicao do cliente recebida\n"); 


        // Function for chatting between client and server 
	    func(connfd);

        bzero(buff, MAX);
    }
} 
