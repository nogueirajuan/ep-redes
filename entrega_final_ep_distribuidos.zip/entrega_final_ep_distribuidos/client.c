// Write CPP code here 
#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>

#define MAX 80 
#define PORT 5000
#define SA struct sockaddr 

int main(int argc, char *argv[]) 
{ 
	int sockfd, connfd; 
	struct sockaddr_in servaddr, cli; 

	//define socket de conexao
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("Falha ao criar socket...\n"); 
		exit(0); 
	} 
	else
		printf("Socket criado com sucesso..\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	//estabelece conexao com o servidor
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	servaddr.sin_port = htons(PORT); 

	if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
		printf("nao foi possivel conectar ao servidor...\n"); 
		exit(0); 
	} 
	else
		printf("conexao estabelecida..\n"); 

	//dispara requisicao
    char buff[MAX];
    write(sockfd, argv[1], sizeof(buff)); 
    printf("=====> req enviada: %s\n", argv[1]);

	//encerra comunicacao com o servidor
	close(sockfd); 
} 
